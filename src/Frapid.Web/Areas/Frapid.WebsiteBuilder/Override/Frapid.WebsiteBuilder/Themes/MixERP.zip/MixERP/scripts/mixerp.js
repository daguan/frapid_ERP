﻿$(document).ready(function ($) {
    if ($.fn.dropdown) {
        $(".dropdown").dropdown();
    };

    var el = $('.stories');
    el.sliderPro({
        width: '100%',
        autoplayDelay: 12000,
        fadeDuration: 800,
        arrows: true,
        buttons: true,
        fade: true,
        fadeOutPreviousSlide: true,
        visibleSize: '100%',
        forceSize: 'fullWidth',
        slideDistance: 0,
        imageScaleMode: 'contain',
        autoHeight: true,
        responsive: true,
        fullScreen: true,
        waitForLayers: true
    });

    $("a[data-module]").click(function() {
        var target = $(this).attr("data-module");
        $("div[data-module]").hide();
        $("div[data-module=" + target + "]").fadeIn(1000);
    });


    if (localStorage.getItem("resourceCached") == null) {
        setTimeout(function () {
            function cacheResource(url) {
                var client = new XMLHttpRequest();
                client.open('GET', url);
                client.send();
            };

            cacheResource('https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.1.8/semantic.min.css');
            cacheResource('https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.1.8/semantic.min.js');
            localStorage.setItem("resourceCached", "true");
        }, 10000);
    };
});

function getCookie(name) {
    var value = "; " + document.cookie;
    var parts = value.split("; " + name + "=");
    if (parts.length === 2) return parts.pop().split(";").shift();
    return null;
};

$(".cookie.policy.accept.button").click(function() {
    document.cookie = "cookie_policy=accepted;";
    $(".cookie.policy.message").remove();
});

var cookiePolicyWasAccepted = getCookie("cookie_policy") === "accepted";

if (cookiePolicyWasAccepted) {
    $(".cookie.policy.message").remove();
};